# Formasyon analizi
