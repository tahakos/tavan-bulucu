# Grafik çizimi
